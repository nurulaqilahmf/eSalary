using System;
using Microsoft.Office.Interop.Excel;
using System.Windows.Forms;

namespace eSalary1
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            Employee.writeExcel();
        }

        public static void writeExcel()
        {
            string filePath = "c:\\Users\\Qila\\Desktop\\eSalary.xlsx"; 
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
            Workbook wb;
            Worksheet ws;

            wb = excel.Workbooks.Open(filePath);
            ws = wb.Worksheets[1];


        }

        
    }
}