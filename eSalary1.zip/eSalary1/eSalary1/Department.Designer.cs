﻿namespace eSalary1
{
    partial class Department
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Department));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblproject = new System.Windows.Forms.Label();
            this.textproject = new System.Windows.Forms.TextBox();
            this.lblworkdesc = new System.Windows.Forms.Label();
            this.textworkdesc = new System.Windows.Forms.TextBox();
            this.btnsave = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-3, -56);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(801, 219);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // lblproject
            // 
            this.lblproject.AutoSize = true;
            this.lblproject.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblproject.Location = new System.Drawing.Point(34, 194);
            this.lblproject.Name = "lblproject";
            this.lblproject.Size = new System.Drawing.Size(227, 23);
            this.lblproject.TabIndex = 2;
            this.lblproject.Text = "DISCIPLINE | PROJECT";
            this.lblproject.Click += new System.EventHandler(this.lblempname_Click);
            // 
            // textproject
            // 
            this.textproject.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textproject.Location = new System.Drawing.Point(280, 190);
            this.textproject.Name = "textproject";
            this.textproject.Size = new System.Drawing.Size(415, 27);
            this.textproject.TabIndex = 6;
            // 
            // lblworkdesc
            // 
            this.lblworkdesc.AutoSize = true;
            this.lblworkdesc.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblworkdesc.Location = new System.Drawing.Point(34, 274);
            this.lblworkdesc.Name = "lblworkdesc";
            this.lblworkdesc.Size = new System.Drawing.Size(213, 23);
            this.lblworkdesc.TabIndex = 7;
            this.lblworkdesc.Text = "WORK DESCRIPTION";
            // 
            // textworkdesc
            // 
            this.textworkdesc.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textworkdesc.Location = new System.Drawing.Point(280, 270);
            this.textworkdesc.Name = "textworkdesc";
            this.textworkdesc.Size = new System.Drawing.Size(415, 27);
            this.textworkdesc.TabIndex = 8;
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnsave.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnsave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnsave.Location = new System.Drawing.Point(671, 366);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(94, 38);
            this.btnsave.TabIndex = 10;
            this.btnsave.Text = "SAVE";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // Department
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.textworkdesc);
            this.Controls.Add(this.lblworkdesc);
            this.Controls.Add(this.textproject);
            this.Controls.Add(this.lblproject);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Department";
            this.Text = "Department";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBox1;
        private Label lblproject;
        private TextBox textproject;
        private Label lblworkdesc;
        private TextBox textworkdesc;
        private Button btnsave;
    }
}