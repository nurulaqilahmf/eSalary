﻿


namespace eSalary1
{
    partial class Employee
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Employee));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblempname = new System.Windows.Forms.Label();
            this.lblpassnum = new System.Windows.Forms.Label();
            this.lblcontactnum = new System.Windows.Forms.Label();
            this.lblposition = new System.Windows.Forms.Label();
            this.textempname = new System.Windows.Forms.TextBox();
            this.textpassnum = new System.Windows.Forms.TextBox();
            this.textcontactnum = new System.Windows.Forms.TextBox();
            this.listposition = new System.Windows.Forms.ListBox();
            this.btnsave = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-10, -53);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(816, 216);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblempname
            // 
            this.lblempname.AutoSize = true;
            this.lblempname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblempname.Location = new System.Drawing.Point(33, 154);
            this.lblempname.Name = "lblempname";
            this.lblempname.Size = new System.Drawing.Size(185, 23);
            this.lblempname.TabIndex = 1;
            this.lblempname.Text = "EMPLOYEE NAME";
            // 
            // lblpassnum
            // 
            this.lblpassnum.AutoSize = true;
            this.lblpassnum.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblpassnum.Location = new System.Drawing.Point(33, 205);
            this.lblpassnum.Name = "lblpassnum";
            this.lblpassnum.Size = new System.Drawing.Size(168, 23);
            this.lblpassnum.TabIndex = 2;
            this.lblpassnum.Text = "E-PASS NUMBER";
            // 
            // lblcontactnum
            // 
            this.lblcontactnum.AutoSize = true;
            this.lblcontactnum.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblcontactnum.Location = new System.Drawing.Point(33, 258);
            this.lblcontactnum.Name = "lblcontactnum";
            this.lblcontactnum.Size = new System.Drawing.Size(198, 23);
            this.lblcontactnum.TabIndex = 3;
            this.lblcontactnum.Text = "CONTACT NUMBER";
            // 
            // lblposition
            // 
            this.lblposition.AutoSize = true;
            this.lblposition.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblposition.Location = new System.Drawing.Point(33, 315);
            this.lblposition.Name = "lblposition";
            this.lblposition.Size = new System.Drawing.Size(106, 23);
            this.lblposition.TabIndex = 4;
            this.lblposition.Text = "POSITION";
            // 
            // textempname
            // 
            this.textempname.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textempname.Location = new System.Drawing.Point(261, 150);
            this.textempname.Name = "textempname";
            this.textempname.Size = new System.Drawing.Size(415, 27);
            this.textempname.TabIndex = 5;
            // 
            // textpassnum
            // 
            this.textpassnum.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textpassnum.Location = new System.Drawing.Point(261, 201);
            this.textpassnum.Name = "textpassnum";
            this.textpassnum.Size = new System.Drawing.Size(415, 27);
            this.textpassnum.TabIndex = 6;
            // 
            // textcontactnum
            // 
            this.textcontactnum.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textcontactnum.Location = new System.Drawing.Point(261, 258);
            this.textcontactnum.Name = "textcontactnum";
            this.textcontactnum.Size = new System.Drawing.Size(415, 27);
            this.textcontactnum.TabIndex = 7;
            // 
            // listposition
            // 
            this.listposition.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listposition.FormattingEnabled = true;
            this.listposition.ItemHeight = 19;
            this.listposition.Location = new System.Drawing.Point(261, 315);
            this.listposition.Name = "listposition";
            this.listposition.Size = new System.Drawing.Size(415, 23);
            this.listposition.TabIndex = 8;
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnsave.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnsave.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnsave.Location = new System.Drawing.Point(694, 388);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(94, 38);
            this.btnsave.TabIndex = 9;
            this.btnsave.Text = "SAVE";
            this.btnsave.UseVisualStyleBackColor = false;
            // 
            // Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.listposition);
            this.Controls.Add(this.textcontactnum);
            this.Controls.Add(this.textpassnum);
            this.Controls.Add(this.textempname);
            this.Controls.Add(this.lblposition);
            this.Controls.Add(this.lblcontactnum);
            this.Controls.Add(this.lblpassnum);
            this.Controls.Add(this.lblempname);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Employee";
            this.Text = "Employee";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBox1;
        private Label lblempname;
        private Label lblpassnum;
        private Label lblcontactnum;
        private Label lblposition;
        private TextBox textempname;
        private TextBox textpassnum;
        private TextBox textcontactnum;
        private ListBox listposition;
        private Button btnsave;
    }
}