﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;
using System.Windows.Forms;

namespace eSalary2
{
    public partial class Department : Form
    {
        public Department()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            String project = textproject.Text;
            String workdesc = textworkdesc.Text;
            MessageBox.Show("Successful Add ");
            Department.writeExcel(project, workdesc);
            
        }
        public static void writeExcel(string project, string workdesc)
        {
            Cursor.Current = Cursors.WaitCursor;
            string filePath = "c:\\Users\\Qila\\Desktop\\Q.xlsx";
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();

            Workbook wb;
            Worksheet ws;

            wb = excel.Workbooks.Open(filePath);
            ws = wb.Worksheets[2];
            ws.Name = "Department";
            ws.Range["A1"].Value = "DISCIPLINE | PROJECT";
            ws.Range["B1"].Value = "WORK DESCRIPTION";

            Range range, range2;

            range = ws.Range["A2"];
            range.Value = project;
            range.WrapText = true;
            range2 = ws.Range["B2"];
            range2.Value = workdesc;
            range2.WrapText = true;
            wb.Save();

            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();


            //close and release
            wb.Close();


            //quit and release
            excel.Quit();


            // Set cursor as default arrow
            Cursor.Current = Cursors.Default;
        }
    }
}
