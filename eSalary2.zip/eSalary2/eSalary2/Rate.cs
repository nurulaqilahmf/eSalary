﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;
using System.Windows.Forms;
using System.Reflection;

namespace eSalary2
{
    public partial class Rate : Form
    {
        public Rate()
        {
            InitializeComponent();
        }

       /* public void writetocell(int i, int j , string s)
        {
            i++;
            j++;
            Worksheet ws;

            ws.Cells[i,j].Value = s;
        } */
        private void btnadd_Click(object sender, EventArgs e)
        {
            String position = txtposition.Text;
            String rate = txtrate.Text;
            MessageBox.Show("position= " + position + " " + "rate= " + rate);
            Rate.writeExcel(position,rate);
            
        }
        public static void writeExcel(string position, string rate)
        {
            Cursor.Current=Cursors.WaitCursor;
            string filePath = "c:\\Users\\Qila\\Desktop\\Q.xlsx";
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();
           
            Workbook wb;
            Worksheet ws;

            wb = excel.Workbooks.Open(filePath);
            ws = wb.Worksheets[1];
            ws.Name = "Rate";
            ws.Range["A1"].Value = "POSITION";
            ws.Range["B1"].Value = "RATE";

            Range range,range2;
            
            range = ws.Range["A2"];
            range.Value = position;
            range.WrapText = true;
            range2 = ws.Range["B2"];
            range2.Value = rate;
            range2.WrapText = true;
            wb.Save();

            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();


            //close and release
            wb.Close();
            

            //quit and release
            excel.Quit();


            // Set cursor as default arrow
            Cursor.Current = Cursors.Default;
        }

        private void txtposition_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
