﻿namespace eSalary2
{
    partial class Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Employee));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblempname = new System.Windows.Forms.Label();
            this.lblposition = new System.Windows.Forms.Label();
            this.lblcnctnum = new System.Windows.Forms.Label();
            this.lblpassnum = new System.Windows.Forms.Label();
            this.textempname = new System.Windows.Forms.TextBox();
            this.textpassnum = new System.Windows.Forms.TextBox();
            this.textcnctnum = new System.Windows.Forms.TextBox();
            this.listposition = new System.Windows.Forms.ListBox();
            this.btnsave = new System.Windows.Forms.Button();
            this.rateBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rateBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-28, -73);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(841, 241);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblempname
            // 
            this.lblempname.AutoSize = true;
            this.lblempname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblempname.Location = new System.Drawing.Point(75, 158);
            this.lblempname.Name = "lblempname";
            this.lblempname.Size = new System.Drawing.Size(185, 23);
            this.lblempname.TabIndex = 1;
            this.lblempname.Text = "EMPLOYEE NAME";
            // 
            // lblposition
            // 
            this.lblposition.AutoSize = true;
            this.lblposition.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblposition.Location = new System.Drawing.Point(75, 322);
            this.lblposition.Name = "lblposition";
            this.lblposition.Size = new System.Drawing.Size(106, 23);
            this.lblposition.TabIndex = 2;
            this.lblposition.Text = "POSITION";
            // 
            // lblcnctnum
            // 
            this.lblcnctnum.AutoSize = true;
            this.lblcnctnum.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcnctnum.Location = new System.Drawing.Point(75, 268);
            this.lblcnctnum.Name = "lblcnctnum";
            this.lblcnctnum.Size = new System.Drawing.Size(198, 23);
            this.lblcnctnum.TabIndex = 3;
            this.lblcnctnum.Text = "CONTACT NUMBER";
            // 
            // lblpassnum
            // 
            this.lblpassnum.AutoSize = true;
            this.lblpassnum.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassnum.Location = new System.Drawing.Point(75, 211);
            this.lblpassnum.Name = "lblpassnum";
            this.lblpassnum.Size = new System.Drawing.Size(168, 23);
            this.lblpassnum.TabIndex = 4;
            this.lblpassnum.Text = "E-PASS NUMBER";
            // 
            // textempname
            // 
            this.textempname.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textempname.Location = new System.Drawing.Point(312, 158);
            this.textempname.Name = "textempname";
            this.textempname.Size = new System.Drawing.Size(361, 27);
            this.textempname.TabIndex = 5;
            // 
            // textpassnum
            // 
            this.textpassnum.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textpassnum.Location = new System.Drawing.Point(312, 211);
            this.textpassnum.Name = "textpassnum";
            this.textpassnum.Size = new System.Drawing.Size(361, 27);
            this.textpassnum.TabIndex = 6;
            // 
            // textcnctnum
            // 
            this.textcnctnum.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textcnctnum.Location = new System.Drawing.Point(312, 268);
            this.textcnctnum.Name = "textcnctnum";
            this.textcnctnum.Size = new System.Drawing.Size(361, 27);
            this.textcnctnum.TabIndex = 7;
            // 
            // listposition
            // 
            this.listposition.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listposition.FormattingEnabled = true;
            this.listposition.ItemHeight = 19;
            this.listposition.Location = new System.Drawing.Point(312, 322);
            this.listposition.Name = "listposition";
            this.listposition.Size = new System.Drawing.Size(361, 23);
            this.listposition.TabIndex = 8;
            this.listposition.SelectedIndexChanged += new System.EventHandler(this.listposition_SelectedIndexChanged);
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.MidnightBlue;
            this.btnsave.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.ForeColor = System.Drawing.Color.Snow;
            this.btnsave.Location = new System.Drawing.Point(686, 381);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(89, 35);
            this.btnsave.TabIndex = 9;
            this.btnsave.Text = "SAVE";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // rateBindingSource
            // 
            this.rateBindingSource.DataSource = typeof(eSalary2.Rate);
            // 
            // Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.listposition);
            this.Controls.Add(this.textcnctnum);
            this.Controls.Add(this.textpassnum);
            this.Controls.Add(this.textempname);
            this.Controls.Add(this.lblpassnum);
            this.Controls.Add(this.lblcnctnum);
            this.Controls.Add(this.lblposition);
            this.Controls.Add(this.lblempname);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Employee";
            this.Text = "Employee";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rateBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblempname;
        private System.Windows.Forms.Label lblposition;
        private System.Windows.Forms.Label lblcnctnum;
        private System.Windows.Forms.Label lblpassnum;
        private System.Windows.Forms.TextBox textempname;
        private System.Windows.Forms.TextBox textpassnum;
        private System.Windows.Forms.TextBox textcnctnum;
        private System.Windows.Forms.ListBox listposition;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.BindingSource rateBindingSource;
    }
}

