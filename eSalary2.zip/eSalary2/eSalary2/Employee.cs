﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;
using System.Windows.Forms;

namespace eSalary2
{
    public partial class Employee : Form
    {
        public Employee()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            
            String empname = textempname.Text;
            String passnum = textpassnum.Text;
            String position = listposition.Text;
            MessageBox.Show("Successful Add ");
            Employee.writeExcel(empname, passnum, position);
        }

        public static void writeExcel(string empname, string passnum , string position)
        {
            Cursor.Current = Cursors.WaitCursor;
            string filePath = "c:\\Users\\Qila\\Desktop\\w.xlsx";
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();

            Workbook wb;
            Worksheet ws;

            wb = excel.Workbooks.Open(filePath);
            ws = wb.Worksheets[1];
            ws.Name = "EMPLOYEE";
            ws.Range["A1"].Value = "EMPLOYEE NAME";
            ws.Range["B1"].Value = "E-PASS NUMBER";
            ws.Range["C1"].Value = "POSITION";

            Range range, range2;

            range = ws.Range["A2"];
            range.Value = empname;
            range2 = ws.Range["B2"];
            range2.Value = passnum;
            wb.Save();

            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();


            //close and release
            wb.Close();


            //quit and release
            excel.Quit();


            // Set cursor as default arrow
            Cursor.Current = Cursors.Default;


        }

        private void listposition_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            string filePath = "c:\\Users\\Qila\\Desktop\\w.xlsx";
            Microsoft.Office.Interop.Excel.Application excel = new Microsoft.Office.Interop.Excel.Application();

            Workbook wb;
            Worksheet ws;

            wb = excel.Workbooks.Open(filePath);
            ws = wb.Worksheets["2"];

            Range usedRange = ws.UsedRange;
            string data = "";
            Range curRange;
            List<string> position = new List<string>();

            try
            {
                foreach (Range row in usedRange.Rows)
                {
                    curRange = (Range)row.Cells[2, 1];
                    data = curRange.Cells.Value.ToString();
                    position.Add(data);
                    wb.Close();

                }
                listposition.DataSource = position;
            }
            catch (Exception)
            {
                Console.WriteLine();
            }
        }
    }
}
